abstract class LayoutState {}

class InitialLayoutState extends LayoutState {}

class ChangeBottomNavLayoutState extends LayoutState {}
