import 'package:flutter/material.dart';

class ListText extends StatelessWidget {
  const ListText({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
